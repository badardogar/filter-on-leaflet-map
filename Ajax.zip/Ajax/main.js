// Initialize the map
var map = L.map('map').setView([30.3753, 69.3451], 6);

// Add a base map tile layer from OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: 'Map data &copy; OpenStreetMap contributors'
}).addTo(map);

// Variable to hold the GeoJSON layer
var geojsonLayer;

// Function to filter the GeoJSON layer based on the state name
function filterLayer(stateName) {
  // Clear the existing GeoJSON layer
  if (geojsonLayer) {
    map.removeLayer(geojsonLayer);
  }

  var requestURL = 'http://localhost:8082/geoserver/india/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=india%3Apak_state&maxFeatures=50&outputFormat=application%2Fjson';

  // Make an AJAX request to retrieve the GeoJSON data
  var xhr = new XMLHttpRequest();
  xhr.open('GET', requestURL);
  xhr.onload = function() {
    if (xhr.status === 200) {
      var data = JSON.parse(xhr.responseText);
      var filteredFeatures = data.features.filter(function(feature) {
        return feature.properties.name_2.toLowerCase().includes(stateName.toLowerCase());
      });

      var filteredGeojson = {
        type: 'FeatureCollection',
        features: filteredFeatures
      };

      // Create a Leaflet GeoJSON layer from the filtered data
      geojsonLayer = L.geoJSON(filteredGeojson, {
        style: {
          color: '#3388ff',
          weight: 2
        }
      }).addTo(map);

      // Fit the map view to the bounds of the GeoJSON layer
      map.fitBounds(geojsonLayer.getBounds());
    }
  };
  xhr.send();
}

// Function to show the complete GeoJSON layer
function showCompleteLayer() {
  // Clear the existing GeoJSON layer
  if (geojsonLayer) {
    map.removeLayer(geojsonLayer);
  }

  var requestURL = 'http://localhost:8082/geoserver/india/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=india%3Apak_state&maxFeatures=50&outputFormat=application%2Fjson';

  // Make an AJAX request to retrieve the GeoJSON data
  var xhr = new XMLHttpRequest();
  xhr.open('GET', requestURL);
  xhr.onload = function() {
    if (xhr.status === 200) {
      var data = JSON.parse(xhr.responseText);

      // Create a Leaflet GeoJSON layer from the complete data
      geojsonLayer = L.geoJSON(data, {
        style: {
          color: '#3388ff',
          weight: 2
        }
      }).addTo(map);

      // Fit the map view to the bounds of the GeoJSON layer
      map.fitBounds(geojsonLayer.getBounds());
    }
  };
  xhr.send();
}

// Event listener for the filter button
document.getElementById('filterButton').addEventListener('click', function() {
  var stateName = document.getElementById('stateNameInput').value;
  filterLayer(stateName);
});

// Event listener for the reset button
document.getElementById('resetButton').addEventListener('click', function() {
  showCompleteLayer();
});

// Show the complete GeoJSON layer when the page loads
showCompleteLayer();
